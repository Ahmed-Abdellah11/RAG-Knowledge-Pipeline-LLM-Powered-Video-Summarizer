"""
summarizer.py
-------------
The "generate" half of RAG: takes the augmented context (retrieved chunks)
and produces a fluent abstractive summary or a direct answer to a user
question, using facebook/bart-large-cnn.

BART has a hard 1024-token input limit, so long augmented contexts are
map-reduced: each retrieved chunk is summarized individually, then the
partial summaries are combined and summarized once more into the final
output. This keeps the pipeline correct even when a video is long and
top_k retrieval pulls in more context than BART can read in one pass.
"""

from typing import List

from transformers import pipeline

DEFAULT_MODEL = "facebook/bart-large-cnn"


class Summarizer:
    def __init__(self, model_name: str = DEFAULT_MODEL, device: int = -1):
        # device=-1 -> CPU. Set to 0 to use the first CUDA GPU if available.
        self._pipe = pipeline("summarization", model=model_name, device=device)

    def _summarize_text(self, text: str, max_length: int = 140, min_length: int = 40) -> str:
        words = text.split()
        if len(words) < 20:
            return text  # too short to bother summarizing further
        out = self._pipe(
            text,
            max_length=max_length,
            min_length=min_length,
            do_sample=False,
            truncation=True,
        )
        return out[0]["summary_text"].strip()

    def summarize_chunks(self, chunk_texts: List[str]) -> str:
        """Map-reduce summarization across the retrieved/augmented chunks."""
        if not chunk_texts:
            return ""

        partial_summaries = [self._summarize_text(t, max_length=100, min_length=25) for t in chunk_texts]
        combined = " ".join(partial_summaries)

        if len(chunk_texts) == 1:
            return partial_summaries[0]

        return self._summarize_text(combined, max_length=180, min_length=50)

    def answer_question(self, chunk_texts: List[str], question: str) -> str:
        """
        BART-large-cnn is a summarizer, not an instruction-following QA model,
        so for question-answering we summarize the augmented context down to
        the essentials, keeping only the parts most relevant to the question
        by prepending it as framing context before summarization.
        """
        context = " ".join(chunk_texts)
        framed = f"Question: {question}\nRelevant transcript context: {context}"
        return self._summarize_text(framed, max_length=150, min_length=30)
